# WorldBox Mod Loader (Android)

Root-based full game file extractor + mod importer for **WorldBox** (`com.mkarpenko.worldbox`).

## Features
- Detect WorldBox install path via root
- Full extract of game data / external / obb (not just json)
- Import local mod (ZIP or folder) — keeps **all** file types
- Steam Workshop style mod import (same full unpack)
- Apply mods directly into game files
- GitHub Actions workflow: zip → APK

## Requirements
- Rooted device (Magisk / KernelSU recommended)
- WorldBox installed
- Android 8.0+

## Build with GitHub Actions (Zip → APK)

### วิธีที่ 1: Push ทั้งโปรเจกต์
1. สร้าง repo ใหม่บน GitHub
2. อัปโหลดโฟลเดอร์นี้ทั้งหมด (หรือ push)
3. ไปที่ **Actions** → **Build APK from Source** → Run workflow
4. ดาวน์โหลด APK จาก Artifacts

### วิธีที่ 2: ใช้ Zip
1. Zip ทั้งโฟลเดอร์ `WorldBoxModLoader` เป็น `WorldBoxModLoader.zip` หรือ `project-source.zip`
2. วางไฟล์ zip ไว้ root ของ repo
3. รัน workflow **Build APK from uploaded ZIP**
4. ดาวน์โหลด APK จาก Artifacts

## Local Build
```bash
./gradlew assembleDebug
```
APK อยู่ที่ `app/build/outputs/apk/debug/`

## Usage
1. เปิดแอพ → อนุญาต root
2. กด **Detect WorldBox**
3. กด **Extract Full Game Files** (ดึงทุกอย่าง)
4. กด **Import Local Mod** หรือ **Import Steam Workshop Mod** แล้วเลือกไฟล์ zip/mod
5. กด **Apply Mods to Game**
6. เปิด WorldBox ใหม่

## Paths used
- Package: `com.mkarpenko.worldbox`
- Work dir: `/data/local/tmp/worldbox_modloader/`
- Mods: `/data/local/tmp/worldbox_modloader/mods/`
- Extracted: `/data/local/tmp/worldbox_modloader/extracted/`

## Notes
- แอพนี้ต้องการ root เพื่อเข้าถึง `/data/data/` และเขียนไฟล์เกม
- แตกไฟล์แบบเต็ม ไม่กรองแค่ json
- รองรับทั้งไฟล์จาก Steam Workshop และไฟล์ที่ใส่เอง
