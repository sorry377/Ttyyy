# WorldBox Mod Loader (Android + Shizuku)

Android WorldBox mod import / extraction utility using **Shizuku UserService** instead of calling `su` directly.

## What changed
- Removed the direct `su` execution helper.
- Added Shizuku API + provider and a Shizuku `UserService` command bridge.
- The app requests Shizuku permission from the user and runs commands through the connected UserService.
- The app checks the UserService UID before enabling game-data operations:
  - `UID 0`: Shizuku was started with Root privileges; private game-data operations can proceed.
  - `UID 2000`: Shizuku is running in ADB/Shell mode. Android protects `/data/user/0/<package>` from this UID, so the app keeps Root-dependent actions disabled.
- Added an on-screen status for Shizuku connection, permission, and execution UID.

## Requirements
- Android 8.0+ (API 26+)
- [Shizuku](https://shizuku.rikka.app/download/) installed and running
- For full WorldBox private-data access, Shizuku must be started using its **Root** backend (for example, via Magisk/KernelSU). Grant this app permission in Shizuku.
- WorldBox installed (`com.mkarpenko.worldbox`)

> Important: Shizuku permission does not itself turn ADB mode into Root. If Shizuku is started using Wireless debugging / ADB, the service normally runs as UID 2000 and cannot access another app's private data directory. The app checks this and will not claim that Root is available.

## Build APK

### GitHub Actions
1. Upload this project to a GitHub repository.
2. Open **Actions** → **Build APK from Source** → **Run workflow**.
3. Download the `WorldBoxModLoader-APK` artifact.

For the zip-based workflow, upload the generated `WorldBoxModLoader-Shizuku.zip` to the repository root and run **Build APK from uploaded ZIP**. The workflow also accepts `WorldBoxModLoader.zip`, `project-source.zip`, and `source.zip`.

### Local build

```bash
./gradlew assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Usage
1. Install and start Shizuku.
2. Open WorldBox Mod Loader and tap **Connect Shizuku / Grant Access**.
3. Grant the permission prompt shown by Shizuku.
4. Confirm that the app reports **Shizuku: ROOT access granted (UID 0)**.
5. Tap **Detect WorldBox**.
6. Use **Extract Full Game Files**, **Import Local Mod**, or **Import Steam Workshop Mod**.
7. Tap **Apply Mods to Game**, then restart WorldBox.

If the status reports **ADB / Shell only (UID 2000)**, stop Shizuku and restart it using the Root backend before reconnecting.

## Work paths
- Package: `com.mkarpenko.worldbox`
- Work directory: `/data/local/tmp/worldbox_modloader/`
- Mods: `/data/local/tmp/worldbox_modloader/mods/`
- Extracted files: `/data/local/tmp/worldbox_modloader/extracted/`

## Implementation notes
- Shizuku API version: `13.1.5`
- Uses `Shizuku.bindUserService(...)` and an AIDL bridge; no direct `su` invocation remains in the application source.
- The UserService runs using the UID of the Shizuku backend selected by the user (Root or ADB/Shell).
