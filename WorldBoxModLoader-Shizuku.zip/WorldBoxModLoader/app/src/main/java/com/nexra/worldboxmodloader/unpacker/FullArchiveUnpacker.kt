package com.nexra.worldboxmodloader.unpacker

import com.nexra.worldboxmodloader.access.ShizukuHelper
import java.io.File
import java.util.zip.ZipFile

object FullArchiveUnpacker {

    /**
     * Unpacks any archive fully (zip, and attempts others via root busybox/unzip/7z if available)
     * Does NOT filter by extension. Keeps everything.
     */
    fun unpack(archivePath: String, destDir: String, onLog: (String) -> Unit): Boolean {
        onLog("Unpacking: $archivePath")
        onLog("Destination: $destDir")

        ShizukuHelper.makeDirs(destDir)

        val lower = archivePath.lowercase()

        return when {
            lower.endsWith(".zip") || lower.endsWith(".apk") || lower.endsWith(".jar") -> {
                unpackZip(archivePath, destDir, onLog)
            }
            else -> {
                // Try system tools first (full support)
                onLog("Trying system unpackers...")
                val try7z = ShizukuHelper.runCommand(
                    "7z x -y -o\"$destDir\" \"$archivePath\" && echo UNPACK_OK"
                )
                if (try7z.contains("UNPACK_OK")) {
                    onLog("Unpacked with 7z")
                    true
                } else {
                    val tryUnzip = ShizukuHelper.runCommand(
                        "unzip -o \"$archivePath\" -d \"$destDir\" && echo UNPACK_OK"
                    )
                    if (tryUnzip.contains("UNPACK_OK")) {
                        onLog("Unpacked with unzip")
                        true
                    } else {
                        onLog("Failed to unpack unknown archive type")
                        false
                    }
                }
            }
        }
    }

    private fun unpackZip(zipPath: String, destDir: String, onLog: (String) -> Unit): Boolean {
        return try {
            // Prefer root unzip for full permissions / large files
            val rootResult = ShizukuHelper.runCommand(
                "unzip -o \"$zipPath\" -d \"$destDir\" && echo UNPACK_OK"
            )
            if (rootResult.contains("UNPACK_OK")) {
                onLog("Unpacked via root unzip")
                return true
            }

            // Fallback pure Java
            onLog("Falling back to Java ZipFile...")
            ZipFile(zipPath).use { zip ->
                val entries = zip.entries()
                var count = 0
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    val outFile = File(destDir, entry.name)
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        zip.getInputStream(entry).use { input ->
                            outFile.outputStream().use { output ->
                                input.copyTo(output)
                            }
                        }
                        count++
                    }
                }
                onLog("Extracted $count files via Java")
            }
            true
        } catch (e: Exception) {
            onLog("Zip unpack error: ${e.message}")
            false
        }
    }

    fun listContents(archivePath: String): List<String> {
        return try {
            ZipFile(archivePath).use { zip ->
                zip.entries().toList().map { it.name }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
