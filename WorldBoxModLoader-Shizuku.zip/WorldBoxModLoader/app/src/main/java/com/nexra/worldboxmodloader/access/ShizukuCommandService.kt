package com.nexra.worldboxmodloader.access

import android.os.Process

/** Runs in the UID selected when Shizuku was started (root or shell/ADB). */
class ShizukuCommandService : ICommandService.Stub() {

    override fun exec(command: String): String {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val output = process.inputStream.bufferedReader().use { it.readText() }
            val exitCode = process.waitFor()
            if (exitCode == 0) output else "$output\n[exit=$exitCode]"
        } catch (e: Exception) {
            "ERROR: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    override fun getUid(): Int = Process.myUid()

    override fun destroy() {
        // Shizuku invokes this transaction when the UserService is removed.
        System.exit(0)
    }
}
