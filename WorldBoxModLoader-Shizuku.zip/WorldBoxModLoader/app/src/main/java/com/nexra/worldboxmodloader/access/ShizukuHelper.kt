package com.nexra.worldboxmodloader.access

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.IBinder
import android.os.RemoteException
import rikka.shizuku.Shizuku

/** Shared connection to a Shizuku UserService. No direct `su` calls are used. */
object ShizukuHelper {

    @Volatile
    private var commandService: ICommandService? = null

    @Volatile
    private var binding = false

    private var serviceArgs: Shizuku.UserServiceArgs? = null
    private var serviceConnection: ServiceConnection? = null

    fun isConnected(): Boolean = commandService != null

    fun bind(context: Context, onResult: (Boolean, String, Int) -> Unit) {
        val existing = commandService
        if (existing != null) {
            try {
                val uid = existing.getUid()
                onResult(true, "Shizuku UserService already connected", uid)
                return
            } catch (_: Exception) {
                commandService = null
            }
        }

        if (binding) return
        if (!Shizuku.pingBinder()) {
            onResult(false, "Shizuku service is not running", -1)
            return
        }

        val args = Shizuku.UserServiceArgs(
            ComponentName(context, ShizukuCommandService::class.java)
        )
            .daemon(false)
            .processNameSuffix("worldbox_mod_loader")
            .tag("worldbox-mod-loader-command-service")
            .version(1)

        val connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                val remote = ICommandService.Stub.asInterface(binder)
                commandService = remote
                binding = false
                val uid = try { remote?.getUid() ?: -1 } catch (_: Exception) { -1 }
                onResult(remote != null, if (remote != null) "Shizuku UserService connected" else "Service binder unavailable", uid)
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                commandService = null
                binding = false
                onResult(false, "Shizuku UserService disconnected", -1)
            }
        }

        serviceArgs = args
        serviceConnection = connection
        binding = true
        try {
            Shizuku.bindUserService(args, connection)
        } catch (e: Exception) {
            binding = false
            commandService = null
            onResult(false, "Unable to bind Shizuku UserService: ${e.message}", -1)
        }
    }

    fun runCommand(command: String): String {
        val remote = commandService ?: return "ERROR: Shizuku UserService is not connected"
        return try {
            remote.exec(command)
        } catch (e: RemoteException) {
            commandService = null
            "ERROR: Shizuku command failed: ${e.message}"
        } catch (e: Exception) {
            "ERROR: Shizuku command failed: ${e.message}"
        }
    }

    fun makeDirs(path: String): Boolean {
        val result = runCommand("mkdir -p ${shellQuote(path)} && echo SHIZUKU_OK")
        return result.contains("SHIZUKU_OK")
    }

    fun exists(path: String): Boolean {
        val result = runCommand("test -e ${shellQuote(path)} && echo SHIZUKU_EXISTS")
        return result.contains("SHIZUKU_EXISTS")
    }

    fun getUid(): Int = try { commandService?.getUid() ?: -1 } catch (_: Exception) { -1 }

    private fun shellQuote(value: String): String = "'" + value.replace("'", "'\\''") + "'"

    fun unbind() {
        val args = serviceArgs
        val connection = serviceConnection
        if (args != null && connection != null) {
            try {
                Shizuku.unbindUserService(args, connection, true)
            } catch (_: Exception) {
                // The service may already have been stopped by Shizuku.
            }
        }
        commandService = null
        serviceConnection = null
        serviceArgs = null
        binding = false
    }
}
