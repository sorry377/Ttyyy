package com.nexra.worldboxmodloader.detector

import com.nexra.worldboxmodloader.access.ShizukuHelper

data class WorldBoxPaths(
    val dataDir: String,
    val externalData: String,
    val obbDir: String,
    val filesDir: String,
    val savesDir: String
)

object WorldBoxDetector {

    private const val PACKAGE = "com.mkarpenko.worldbox"

    private val possibleDataPaths = listOf(
        "/data/data/$PACKAGE",
        "/data/user/0/$PACKAGE"
    )

    private val possibleExternalPaths = listOf(
        "/storage/emulated/0/Android/data/$PACKAGE",
        "/sdcard/Android/data/$PACKAGE"
    )

    private val possibleObbPaths = listOf(
        "/storage/emulated/0/Android/obb/$PACKAGE",
        "/sdcard/Android/obb/$PACKAGE"
    )

    fun detect(): WorldBoxPaths? {
        val dataDir = possibleDataPaths.firstOrNull { ShizukuHelper.exists(it) }
            ?: return null

        val external = possibleExternalPaths.firstOrNull { ShizukuHelper.exists(it) } ?: ""
        val obb = possibleObbPaths.firstOrNull { ShizukuHelper.exists(it) } ?: ""

        val externalFiles = if (external.isNotBlank()) "$external/files" else ""
        val filesDir = when {
            externalFiles.isNotBlank() && ShizukuHelper.exists(externalFiles) -> externalFiles
            ShizukuHelper.exists("$dataDir/files") -> "$dataDir/files"
            else -> "$dataDir/files"
        }

        val savesDir = "$filesDir/saves"

        return WorldBoxPaths(
            dataDir = dataDir,
            externalData = external,
            obbDir = obb,
            filesDir = filesDir,
            savesDir = savesDir
        )
    }

    fun isInstalled(): Boolean {
        return detect() != null
    }
}
