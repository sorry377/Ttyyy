package com.nexra.worldboxmodloader.ui

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.nexra.worldboxmodloader.R
import com.nexra.worldboxmodloader.access.ShizukuHelper
import com.nexra.worldboxmodloader.detector.WorldBoxDetector
import com.nexra.worldboxmodloader.detector.WorldBoxPaths
import com.nexra.worldboxmodloader.extractor.GameFileExtractor
import com.nexra.worldboxmodloader.mod.ModManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvRootStatus: TextView
    private lateinit var tvGameStatus: TextView
    private lateinit var tvLog: TextView
    private lateinit var btnShizuku: Button
    private lateinit var btnDetect: Button
    private lateinit var btnExtract: Button
    private lateinit var btnImportLocal: Button
    private lateinit var btnSteamMod: Button
    private lateinit var btnApplyMods: Button

    private var gamePaths: WorldBoxPaths? = null
    private var hasShizukuRoot = false
    private val scope = CoroutineScope(Dispatchers.Main)
    private val PICK_MOD = 1001
    private val REQUEST_SHIZUKU_PERMISSION = 2201

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread {
            log("Shizuku service detected.")
            updateShizukuButtonState()
            if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED && !ShizukuHelper.isConnected()) {
                bindShizukuCommandService()
            }
        }
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        runOnUiThread {
            ShizukuHelper.unbind()
            hasShizukuRoot = false
            setPrivilegedFeaturesEnabled(false)
            tvRootStatus.text = "Shizuku: Service stopped"
            tvStatus.text = "Status: Shizuku disconnected"
            log("Shizuku service stopped. Start it again and reconnect.")
        }
    }

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_SHIZUKU_PERMISSION) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                log("Shizuku permission granted.")
                bindShizukuCommandService()
            } else {
                hasShizukuRoot = false
                setPrivilegedFeaturesEnabled(false)
                tvRootStatus.text = "Shizuku: Permission denied"
                log("Permission denied. Grant this app access in Shizuku and try again.")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvRootStatus = findViewById(R.id.tvRootStatus)
        tvGameStatus = findViewById(R.id.tvGameStatus)
        tvLog = findViewById(R.id.tvLog)
        btnShizuku = findViewById(R.id.btnShizuku)
        btnDetect = findViewById(R.id.btnDetect)
        btnExtract = findViewById(R.id.btnExtract)
        btnImportLocal = findViewById(R.id.btnImportLocal)
        btnSteamMod = findViewById(R.id.btnSteamMod)
        btnApplyMods = findViewById(R.id.btnApplyMods)

        setPrivilegedFeaturesEnabled(false)
        btnExtract.isEnabled = false
        btnImportLocal.isEnabled = false
        btnSteamMod.isEnabled = false
        btnApplyMods.isEnabled = false

        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)

        btnShizuku.setOnClickListener { requestShizukuAccess() }
        btnDetect.setOnClickListener { detectGame() }
        btnExtract.setOnClickListener { extractGame() }
        btnImportLocal.setOnClickListener { pickModFile() }
        btnSteamMod.setOnClickListener { pickModFile() }
        btnApplyMods.setOnClickListener { applyMods() }

        updateShizukuButtonState()
        if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            bindShizukuCommandService()
        }
    }

    override fun onResume() {
        super.onResume()
        updateShizukuButtonState()
        if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED && !ShizukuHelper.isConnected()) {
            bindShizukuCommandService()
        }
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        ShizukuHelper.unbind()
        super.onDestroy()
    }

    private fun log(msg: String) {
        runOnUiThread { tvLog.append("$msg\n") }
    }

    private fun updateShizukuButtonState() {
        val running = Shizuku.pingBinder()
        btnShizuku.text = when {
            !running -> "Start Shizuku, then tap here"
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> "Shizuku Permission Granted"
            else -> "Grant Shizuku Permission"
        }
        if (!running) {
            tvRootStatus.text = "Shizuku: Not running"
        }
    }

    private fun requestShizukuAccess() {
        if (!Shizuku.pingBinder()) {
            log("Shizuku is not running. Open Shizuku, start its service, then return here.")
            val launchIntent = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (launchIntent != null) {
                startActivity(launchIntent)
            } else {
                Toast.makeText(this, "Please install Shizuku first", Toast.LENGTH_LONG).show()
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))
            }
            return
        }

        if (Shizuku.isPreV11()) {
            tvRootStatus.text = "Shizuku: Unsupported version"
            log("This app requires Shizuku API/server v11 or newer. Update Shizuku.")
            return
        }

        try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                log("Shizuku permission is already granted. Connecting UserService...")
                bindShizukuCommandService()
            } else {
                Shizuku.requestPermission(REQUEST_SHIZUKU_PERMISSION)
            }
        } catch (e: Exception) {
            log("Shizuku permission error: ${e.message}")
            tvRootStatus.text = "Shizuku: Permission request failed"
        }
    }

    private fun bindShizukuCommandService() {
        ShizukuHelper.bind(this) { success, message, uid ->
            runOnUiThread {
                if (!success) {
                    hasShizukuRoot = false
                    setPrivilegedFeaturesEnabled(false)
                    tvRootStatus.text = "Shizuku: Connection failed"
                    log(message)
                    return@runOnUiThread
                }

                when (uid) {
                    0 -> {
                        hasShizukuRoot = true
                        tvRootStatus.text = "Shizuku: ROOT access granted (UID 0)"
                        tvStatus.text = "Status: Shizuku Root ready"
                        btnShizuku.text = "Shizuku Root Connected"
                        setPrivilegedFeaturesEnabled(true)
                        log("$message — running as UID 0 (Root).")
                        scope.launch {
                            withContext(Dispatchers.IO) { ModManager.ensureDirs() }
                        }
                    }
                    2000 -> {
                        hasShizukuRoot = false
                        tvRootStatus.text = "Shizuku: ADB / Shell only (UID 2000)"
                        tvStatus.text = "Status: Root mode required"
                        btnShizuku.text = "Shizuku Connected — ADB Mode"
                        setPrivilegedFeaturesEnabled(false)
                        log("$message — UID 2000 is ADB/Shell, not Root.")
                        log("WorldBox private data is protected from ADB. Restart Shizuku using Root mode (Magisk/KernelSU), then reconnect.")
                    }
                    else -> {
                        hasShizukuRoot = false
                        tvRootStatus.text = "Shizuku: Unknown UID ($uid)"
                        setPrivilegedFeaturesEnabled(false)
                        log("Shizuku returned unexpected UID $uid. Root access is required for this project.")
                    }
                }
            }
        }
    }

    private fun setPrivilegedFeaturesEnabled(enabled: Boolean) {
        btnDetect.isEnabled = enabled
        if (!enabled) {
            btnExtract.isEnabled = false
            btnImportLocal.isEnabled = false
            btnSteamMod.isEnabled = false
            btnApplyMods.isEnabled = false
        }
    }

    private fun detectGame() {
        if (!hasShizukuRoot) {
            log("Connect Shizuku with Root mode first.")
            return
        }
        scope.launch {
            tvStatus.text = "Status: Detecting..."
            val paths = withContext(Dispatchers.IO) { WorldBoxDetector.detect() }
            gamePaths = paths
            if (paths != null) {
                tvGameStatus.text = "WorldBox: Found\n${paths.dataDir}"
                tvStatus.text = "Status: Game detected"
                btnExtract.isEnabled = true
                btnImportLocal.isEnabled = true
                btnSteamMod.isEnabled = true
                btnApplyMods.isEnabled = true
                log("Detected WorldBox at ${paths.dataDir}")
                log("Files dir: ${paths.filesDir}")
            } else {
                tvGameStatus.text = "WorldBox: Not found"
                tvStatus.text = "Status: Not installed / inaccessible"
                btnExtract.isEnabled = false
                btnImportLocal.isEnabled = false
                btnSteamMod.isEnabled = false
                btnApplyMods.isEnabled = false
                log("WorldBox package com.mkarpenko.worldbox was not found or cannot be accessed.")
            }
        }
    }

    private fun extractGame() {
        val paths = gamePaths ?: return
        if (!hasShizukuRoot) return
        scope.launch {
            tvStatus.text = "Status: Extracting full files..."
            btnExtract.isEnabled = false
            val output = withContext(Dispatchers.IO) {
                val out = ModManager.getWorkDirs()["extracted"]!!
                val extracted = GameFileExtractor.extractFull(paths, out) { log(it) }
                val size = GameFileExtractor.getExtractSize(out)
                Pair(extracted, size)
            }
            tvStatus.text = if (output.first) "Status: Extract done" else "Status: Extract failed"
            log("Extract size: ${output.second}")
            btnExtract.isEnabled = true
        }
    }

    private fun pickModFile() {
        if (!hasShizukuRoot) return
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(intent, "Select Mod ZIP / File"), PICK_MOD)
    }

    @Deprecated("Legacy file picker result used for compatibility with this project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_MOD && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            if (!hasShizukuRoot) return
            scope.launch {
                tvStatus.text = "Status: Importing mod..."
                val importResult = withContext(Dispatchers.IO) {
                    val tmp = "/data/local/tmp/worldbox_modloader/staging/import_${System.currentTimeMillis()}.zip"
                    try {
                        contentResolver.openInputStream(uri)?.use { input ->
                            val localTmp = cacheDir.resolve("mod_import_${System.currentTimeMillis()}.zip")
                            localTmp.outputStream().use { output -> input.copyTo(output) }
                            val copied = ShizukuHelper.runCommand("cp '${localTmp.absolutePath.replace("'", "'\\''")}' '$tmp' && echo COPY_OK")
                            if (!copied.contains("COPY_OK")) {
                                log("Unable to stage mod file through Shizuku: ${copied.trim()}")
                                false
                            } else {
                                ModManager.importLocalMod(tmp) { log(it) }
                            }
                        } ?: false
                    } catch (e: Exception) {
                        log("Import error: ${e.message}")
                        false
                    }
                }
                val importedMods = withContext(Dispatchers.IO) { ModManager.listImportedMods() }
                tvStatus.text = if (importResult) "Status: Mod imported" else "Status: Mod import failed"
                log("Imported mods: $importedMods")
            }
        }
    }

    private fun applyMods() {
        val paths = gamePaths ?: return
        if (!hasShizukuRoot) return
        scope.launch {
            tvStatus.text = "Status: Applying mods..."
            btnApplyMods.isEnabled = false
            val applied = withContext(Dispatchers.IO) {
                ModManager.applyAllMods(paths) { log(it) }
            }
            tvStatus.text = if (applied) "Status: Mods applied - restart game" else "Status: Apply failed / no mods"
            btnApplyMods.isEnabled = true
        }
    }
}
