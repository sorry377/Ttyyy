package com.nexra.worldboxmodloader.extractor

import com.nexra.worldboxmodloader.detector.WorldBoxPaths
import com.nexra.worldboxmodloader.access.ShizukuHelper
import java.io.File

object GameFileExtractor {

    // Extract EVERYTHING, not just json
    private val importantRelativePaths = listOf(
        "files",
        "files/saves",
        "files/StreamingAssets",
        "files/assets",
        "cache",
        "code_cache",
        "shared_prefs",
        "app_webview"
    )

    fun extractFull(paths: WorldBoxPaths, outputDir: String, onLog: (String) -> Unit): Boolean {
        onLog("Starting full extract...")
        onLog("Source data: ${paths.dataDir}")
        onLog("Output: $outputDir")

        ShizukuHelper.makeDirs(outputDir)

        // Full recursive copy of data dir
        onLog("Copying full data directory...")
        val dataCopy = ShizukuHelper.runCommand(
            "cp -a \"${paths.dataDir}/.\" \"$outputDir/data/\" && echo COPY_OK"
        )
        onLog(dataCopy.trim())

        if (paths.externalData.isNotBlank()) {
            onLog("Copying external data...")
            ShizukuHelper.makeDirs("$outputDir/external")
            val extCopy = ShizukuHelper.runCommand(
                "cp -a \"${paths.externalData}/.\" \"$outputDir/external/\" && echo COPY_OK"
            )
            onLog(extCopy.trim())
        }

        if (paths.obbDir.isNotBlank()) {
            onLog("Copying OBB...")
            ShizukuHelper.makeDirs("$outputDir/obb")
            val obbCopy = ShizukuHelper.runCommand(
                "cp -a \"${paths.obbDir}/.\" \"$outputDir/obb/\" && echo COPY_OK"
            )
            onLog(obbCopy.trim())
        }

        // Also dump file list for reference
        onLog("Generating file list...")
        val listResult = ShizukuHelper.runCommand(
            "find \"$outputDir\" -type f | head -n 500 > \"$outputDir/filelist.txt\" && echo LIST_OK"
        )
        onLog(listResult.trim())

        onLog("Full extract finished.")
        return true
    }

    fun getExtractSize(outputDir: String): String {
        val result = ShizukuHelper.runCommand("du -sh \"$outputDir\" 2>/dev/null | cut -f1")
        return result.trim().ifBlank { "unknown" }
    }
}
