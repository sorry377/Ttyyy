package com.nexra.worldboxmodloader.mod

import com.nexra.worldboxmodloader.detector.WorldBoxPaths
import com.nexra.worldboxmodloader.access.ShizukuHelper
import com.nexra.worldboxmodloader.unpacker.FullArchiveUnpacker
import java.io.File

object ModManager {

    private const val MODS_WORK_DIR = "/data/local/tmp/worldbox_modloader/mods"
    private const val EXTRACTED_DIR = "/data/local/tmp/worldbox_modloader/extracted"
    private const val STAGING_DIR = "/data/local/tmp/worldbox_modloader/staging"

    fun ensureDirs() {
        ShizukuHelper.makeDirs(MODS_WORK_DIR)
        ShizukuHelper.makeDirs(EXTRACTED_DIR)
        ShizukuHelper.makeDirs(STAGING_DIR)
    }

    fun importLocalMod(sourcePath: String, onLog: (String) -> Unit): Boolean {
        ensureDirs()
        onLog("Importing local mod: $sourcePath")

        val name = File(sourcePath).nameWithoutExtension
        val dest = "$MODS_WORK_DIR/$name"

        ShizukuHelper.makeDirs(dest)

        return if (File(sourcePath).isDirectory) {
            val result = ShizukuHelper.runCommand("cp -a \"$sourcePath/.\" \"$dest/\" && echo OK")
            onLog(result.trim())
            result.contains("OK")
        } else {
            FullArchiveUnpacker.unpack(sourcePath, dest, onLog)
        }
    }

    fun importSteamWorkshopStyle(modFolderOrZip: String, onLog: (String) -> Unit): Boolean {
        // Steam Workshop mods for WorldBox are usually folders or zips containing
        // the same structure as local mods. Treat them the same + full extract.
        onLog("Treating as Steam Workshop style mod...")
        return importLocalMod(modFolderOrZip, onLog)
    }

    fun listImportedMods(): List<String> {
        val result = ShizukuHelper.runCommand("ls -1 \"$MODS_WORK_DIR\" 2>/dev/null")
        return result.lines().filter { it.isNotBlank() }
    }

    /**
     * Apply all imported mods into the live game directories.
     * Full overwrite / merge of every file type.
     */
    fun applyAllMods(paths: WorldBoxPaths, onLog: (String) -> Unit): Boolean {
        ensureDirs()
        val mods = listImportedMods()
        if (mods.isEmpty()) {
            onLog("No mods imported yet")
            return false
        }

        onLog("Applying ${mods.size} mod(s)...")

        for (mod in mods) {
            val modPath = "$MODS_WORK_DIR/$mod"
            onLog("→ Applying: $mod")

            // Common WorldBox mobile mod targets
            val targets = listOf(
                paths.filesDir,
                "${paths.filesDir}/StreamingAssets",
                "${paths.filesDir}/assets",
                paths.dataDir
            )

            // Copy everything from mod into game files (full, no filter)
            val copyResult = ShizukuHelper.runCommand(
                """
                if [ -d "$modPath" ]; then
                    cp -a "$modPath/." "${paths.filesDir}/" 2>/dev/null || true
                    cp -a "$modPath/." "${paths.dataDir}/" 2>/dev/null || true
                    echo APPLY_OK
                else
                    echo APPLY_FAIL
                fi
                """.trimIndent()
            )
            onLog(copyResult.trim())
        }

        // Fix permissions so game can read
        ShizukuHelper.runCommand(
            "chmod -R 777 \"${paths.filesDir}\" 2>/dev/null; chown -R $(stat -c %u:%g ${paths.dataDir}) \"${paths.filesDir}\" 2>/dev/null; echo PERM_OK"
        )

        onLog("All mods applied. Restart WorldBox.")
        return true
    }

    fun getWorkDirs(): Map<String, String> {
        return mapOf(
            "mods" to MODS_WORK_DIR,
            "extracted" to EXTRACTED_DIR,
            "staging" to STAGING_DIR
        )
    }
}
