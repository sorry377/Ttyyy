package com.nexra.worldboxmodloader.access;

/** Commands are executed by the Shizuku UserService process. */
interface ICommandService {
    String exec(String command);
    int getUid();
    void destroy() = 16777114;
}
